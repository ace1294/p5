package edu.uiuc.detectRefactorings.detection;

import edu.uiuc.detectRefactorings.util.Node;

public class computeLikelinessVisitor {
	public static final computeLikelinessVisitor instance = new computeLikelinessVisitor();

	public double computeLikeliness(Node node1, Node node12) {
		return visit(node1, node12);
	}

	public double visit(Node node1, Node node12) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
