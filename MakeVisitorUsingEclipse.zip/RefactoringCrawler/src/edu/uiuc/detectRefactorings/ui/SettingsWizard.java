package edu.uiuc.detectRefactorings.ui;

import org.eclipse.jface.wizard.Wizard;

public class SettingsWizard extends Wizard {

	public boolean performFinish() {
		// TODO Auto-generated method stub
		return false;
	}

}
